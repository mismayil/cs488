#include "Material.hpp"

Material::Material()
{}

Material::~Material()
{}
