#include "Ray.hpp"

Ray::Ray(glm::vec3 o, glm::vec3 d) : o(o), d(d) {}
